class EntityNotFoundException(Exception):
    pass
